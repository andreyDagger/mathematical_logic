#include <iostream>
#include <sstream>
#include <cassert>
#include <vector>
#include <map>
#include <algorithm>
#include <set>
#include "expression.h"
#include "parser/expression.tab.h"
#include "parser/expression.lexer.h"
using namespace std;

extern expression* result;

void yyerror(const char *error) {
    cerr << error;
}

int yywrap() {
    return 1;
}

vector<string> axioms = {
	"A->B->A",
	"(A->B)->(A->B->C)->(A->C)",
	"A->B->A&B",
	"A&B->A",
	"A&B->B",
	"A->A|B",
	"B->A|B",
	"(A->C)->(B->C)->(A|B->C)",
	"(A->B)->(A->!B)->!A",
	"!!A->A"
};

vector<expression*> axioms_expr;

bool is_variable(expression* e) {
	return dynamic_cast<variable*>(e) != nullptr;
}

string bunch(expression* e) {
	assert(!is_variable(e));
	implication* imp = dynamic_cast<implication*>(e);
	disjunction* dis = dynamic_cast<disjunction*>(e);
	conjunction* con = dynamic_cast<conjunction*>(e);
	negation* neg = dynamic_cast<negation*>(e);
	if (imp != nullptr) return "->";
	else if (dis != nullptr) return "&";
	else if (con != nullptr) return "|";
	else if (neg != nullptr) return "-";
	assert(0);
}

expression* get_left(expression* e) {
	assert(!is_variable(e));
	implication* imp = dynamic_cast<implication*>(e);
	disjunction* dis = dynamic_cast<disjunction*>(e);
	conjunction* con = dynamic_cast<conjunction*>(e);
	negation* neg = dynamic_cast<negation*>(e);
	if (imp != nullptr) return imp->_left;
	else if (dis != nullptr) return dis->_left;
	else if (con != nullptr) return con->_left;
	assert(0);
}

expression* get_right(expression* e) {
	assert(!is_variable(e));
	implication* imp = dynamic_cast<implication*>(e);
	disjunction* dis = dynamic_cast<disjunction*>(e);
	conjunction* con = dynamic_cast<conjunction*>(e);
	negation* neg = dynamic_cast<negation*>(e);
	if (imp != nullptr) return imp->_right;
	else if (dis != nullptr) return dis->_right;
	else if (con != nullptr) return con->_right;
	assert(0);
}

map<string, string> eq_axiom_who;
bool eq_axiom(expression* axi, expression* expr) {
	string name1 = axi->prefix_form();
	string name2 = expr->prefix_form();
	
	// cout << name1 << " " << name2 << "\n";
	
	auto check_names = [&]() {
		if (eq_axiom_who.count(name1)) {
			if (eq_axiom_who[name1] != name2)
				return false;
		} else {
			eq_axiom_who[name1] = name2;
		}
		return true;
	};
	
	if (is_variable(axi)) {
		return check_names();
	}
	if (is_variable(expr)) {
		return false;
	}
	if (bunch(axi) != bunch(expr)) return false;
	if (dynamic_cast<negation*>(axi) != nullptr) {
		return eq_axiom(dynamic_cast<negation*>(axi)->_expr, dynamic_cast<negation*>(expr)->_expr);
	}
		
	return eq_axiom(get_left(axi), get_left(expr)) && eq_axiom(get_right(axi), get_right(expr)); 
}

int axiom_number(expression* expr) {
	for (int i = 0; i < axioms.size(); ++i) {
		eq_axiom_who.clear();
		if (eq_axiom(axioms_expr[i], expr)) {
			return i + 1;
		}
	}
	return 0;
}

expression* my_parse(const string& s) {
	yy_scan_string(s.c_str());
	yyparse();
	return result;
}

void precalc() {
	axioms_expr.resize(axioms.size());
	for (int i = 0; i < axioms.size(); ++i) {
		axioms_expr[i] = my_parse(axioms[i]);
	}
}

template <typename T>
void print_vector(const vector<T>& v) {
	for (auto&& x : v) cout << x << " ";
}

vector<string> get_imp_seq(expression* e) {
	if (is_variable(e)) {
		return {e->prefix_form()};
	}
	if (bunch(e) == "->") {
		vector<string> res = {get_left(e)->prefix_form()};
		vector<string> tmp = get_imp_seq(get_right(e));
		res.insert(res.end(), tmp.begin(), tmp.end());
		return res;
	} else {
		return {e->prefix_form()};
	}
}

bool deduction(vector<string> context_a, expression* a, vector<string> context_b, expression* b) {
	vector<string> imp_seq_a = get_imp_seq(a);
	vector<string> imp_seq_b = get_imp_seq(b);
	if (imp_seq_a.back() != imp_seq_b.back()) {
		return false;
	}
	multiset<string> a_mset(context_a.begin(), context_a.end());
	multiset<string> b_mset(context_b.begin(), context_b.end());
	for (auto&& s : imp_seq_a) {
		a_mset.insert(s);
	}
	for (auto&& s : imp_seq_b) {
		b_mset.insert(s);
	}
	return a_mset == b_mset;
}

int main() {
    //freopen("/home/andrey/hw0-reference-solutions/B/out/input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    precalc();
    
    vector<vector<string>> context_vector;
    vector<string> right_vector;
    vector<expression*> right_expr;
    
    map<vector<string>, map<string, pair<int, int>>> mp_provable;
    map<vector<string>, map<string, vector<pair<string, int>>>> a_b;
    map<vector<string>, map<string, int>> was;
    
    map<string, map<vector<string>, int>> ded;
    
    string line;
    int line_idx = 0;
    while (getline(cin, line)) {
    	++line_idx;
    	
	cout << "[" << line_idx << "] " << line << " ";
    	int idx = line.find("|-");
    	string context = line.substr(0, idx);
    	string to_prove = line.substr(idx + 2);
    	vector<expression*> context_expr;
    	stringstream ss(context);
    	string cur_expr;
    	context_vector.emplace_back();
    	while (getline(ss, cur_expr, ',')) {
		context_expr.push_back(my_parse(cur_expr));
		context_vector.back().push_back(context_expr.back()->prefix_form());
    	}
    	
	expression* right = my_parse(to_prove);
	string right_string = right->prefix_form();
	right_vector.push_back(right_string);
	right_expr.push_back(right);
	
	vector<string> canonical_context = context_vector.back();
	sort(canonical_context.begin(), canonical_context.end());
	
	auto& tmp = mp_provable[canonical_context];
	
	int num = axiom_number(right);
	if (num != 0) {
		cout << "[Ax. sch. " << num << "]\n";
	} else {
	
		bool ok = false;
		for (int i = 0; i < context_expr.size(); ++i) {
			if (context_expr[i]->prefix_form() == right_string) {
				cout << "[Hyp. " << i + 1 << "]\n";
				ok = true;
				break;
			}
		}

		if (!ok) {
			if (tmp.count(right_string)) {
				auto [i, j] = tmp[right_string];
				cout << "[M.P. " << i << ", " << j << "]\n";
			} else {
				ok = false;
				
				vector<string> imp_seq = get_imp_seq(right);
				vector<string> rest(context_vector.back().begin(), context_vector.back().end());
				rest.insert(rest.end(), imp_seq.begin(), imp_seq.end());
				sort(rest.begin(), rest.end());
				if (ded[imp_seq.back()].count(rest)) {
					cout << "[Ded. " << ded[imp_seq.back()][rest] << "]\n";
				} else {
					cout << "[Incorrect]\n";
				}
				/* for (int i = 0; i < (int)right_expr.size() - 1; ++i) {
					if (deduction(context_vector[i], right_expr[i], context_vector.back(), right_expr.back())) {
						cout << "[Ded. " << i + 1 << "]\n";
						ok = true;
						break;
					}
				}
				if (!ok) {
					cout << "[Incorrect]\n";
				}*/
			}
		}
	}

	
	for (auto&& [b, a_b_idx] : a_b[canonical_context][right_string]) {
		tmp[b] = {line_idx, a_b_idx};
	}
	if (!is_variable(right) && bunch(right) == "->") {
		string alpha = get_left(right)->prefix_form();
		string beta = get_right(right)->prefix_form();
		if (was[canonical_context].count(alpha)) {
			tmp[beta] = {was[canonical_context][alpha], line_idx};
		}
		
		a_b[canonical_context][alpha].emplace_back(beta, line_idx);
	}
	was[canonical_context][right_string] = line_idx;
	
	vector<string> imp_seq = get_imp_seq(right);
	vector<string> rest(context_vector.back().begin(), context_vector.back().end());
	rest.insert(rest.end(), imp_seq.begin(), imp_seq.end());
	sort(rest.begin(), rest.end());
	ded[imp_seq.back()][rest] = line_idx;
	
	/* cout << "WAS:\n";
	for (auto&& [cont, mapik] : was) {
		for (auto&& [nm, i] : mapik) {
			print_vector(cont);
			cout << " : " << nm << " : " << i << "\n";
		}
	}
	cout << "WAS END\n"; */
    }
    
    
    /*string expression;
    cin >> expression;
    yy_scan_string(expression.c_str());
    yyparse();
    auto r1 = result;
    cin >> expression;
    yy_scan_string(expression.c_str());
    yyparse();
    auto r2 = result;
    std::cout << r1->prefix_form() << std::endl;
    std::cout << r2->prefix_form() << std::endl;*/
    
    return 0;
}
